
public class SongLyrics {

	public static void main(String[] args) {
		System.out.println("At first I was afraid, I was petrified.");
		System.out.println("Kept thinking I could never live without you by my side.");
		System.out.println("I Will Survive By Gloria Gaynor");
	}

}
