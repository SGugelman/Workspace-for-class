
public class MovieQuote {

	public static void main(String[] args) {
		System.out.println("Do or do not. There is no try");
		System.out.println("-Master Yoda");
		System.out.println("Star Wars EpisodeV: The Empire Strikes Back");
		System.out.println("1980");
	}

}
